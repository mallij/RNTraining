import React from 'react';
import { Button, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import FontAwesomeIcon from 'react-native-vector-icons/FontAwesome5';

import Welcome from './Welcome';
import Home from './Home';
import Profile from './Profile';

const Tab = createBottomTabNavigator();

function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name='Home' component={Home}
          options={({ route }) => ({
          tabBarIcon: () => {
            // You can return any component that you like here!
            return <Image style={{width: 20, height: 20}} source={require('../images/home.png')}/>;
          }
        })}
        />
        <Tab.Screen name='Welcome' component={Welcome}
        options={({ route }) => ({
          tabBarBadge: 3,
        tabBarIcon: () => {
          // You can return any component that you like here!
          return <Image style={{width: 20, height: 20}} source={require('../images/welcome.png')}/>;
        }
      })}/>
        <Tab.Screen name='Profile' component={Profile}
        options={({ route }) => ({
          tabBarBadge: 1,
        tabBarIcon: () => {
          // You can return any component that you like here!
          return <Image style={{width: 20, height: 20}} source={require('../images/user.png')}/>;
        }
      })}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default App;
