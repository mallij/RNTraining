
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';

const Profile = (props) => {
  // var dataFromWelcome = props.route.params.info;
  // var amountFromWelcome = props.route.params.amount;
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />
      <TextInput
      style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
      placeholder={'Enter Name'} />
      <Text style={styles.titleStyle}> Welcome to Home </Text>
      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => props.navigation.navigate('MyProfile')}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Profile
        </Text>
      </TouchableOpacity>

      {
        // <Text style={styles.titleStyle}> Info recieved from Welcome : {dataFromWelcome} - {amountFromWelcome} </Text>
    }
      </View>
      </SafeAreaView>
      );
}

export default Profile;
