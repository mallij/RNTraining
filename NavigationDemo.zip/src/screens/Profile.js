
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';
import { CommonActions } from '@react-navigation/native';

const Home = (props) => {
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />
      <TextInput
      style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
      placeholder={'Enter Name'} />
      <Text style={styles.titleStyle}> Welcome to Profile </Text>
      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() =>
        props.navigation.dispatch(
        CommonActions.reset({
          routes: [
            { name: 'MyProfile' }
          ],
        })
      )}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Go Back
        </Text>
      </TouchableOpacity>
      </View>
      </SafeAreaView>
      );
}

export default Home;
