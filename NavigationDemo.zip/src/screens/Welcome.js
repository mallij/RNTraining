
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Pressable
} from 'react-native';
import styles from './styles/welcomeStyles';

const Welcome = (props) => {
  var data;
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={styles.titleStyle}> Welcome to RN </Text>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />
      <TextInput
      onChangeText={(text) => data = text}
      style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
      placeholder={'Enter Name'} />
        <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity = {1}
        onPress={() => props.navigation.navigate('MyHome', {info: data, amount: 100})}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          Go Home
          </Text>
        </TouchableOpacity>

        <Pressable
          style={styles.buttonStylePressable}
        onPress={() => props.navigation.navigate('MyHome', {info: data, amount: 100})}>
          <Text>I'm pressable!</Text>
        </Pressable>
      <Text style={styles.titleStyle}> {} </Text>
      </View>
      </SafeAreaView>
      );
}

export default Welcome;
