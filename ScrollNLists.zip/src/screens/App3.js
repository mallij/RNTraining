
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Alert,
  ScrollView,
  FlatList,
  TouchableHighlight
} from 'react-native';
import styles from './styles/welcomeStyles';

const App = () => {
  const DATA = [
  {
    id:"1",
    title:"Data Structures"
  },
  {
    id:"2",
    title:"STL"
  },
  {
    id:"3",
    title:"C++"
  },
  {
    id:"4",
    title:"Java"
  },
  {
    id:"5",
    title:"Python"
  },
  {
    id:"6",
    title:"CP"
  },
  {
    id:"7",
    title:"ReactJs"
  },
  {
    id:"8",
    title:"NodeJs"
  },
  {
    id:"9",
    title:"MongoDb"
  }
];

const itemSeparator = ()=>(
  <View style={styles.itemSeparator} />
);

const constructItem = ({item, index, separators})=>(
  <TouchableHighlight
      key={item.key}
      onPress={() => {console.log('====> ', item)}}
      onShowUnderlay={separators.highlight}
      onHideUnderlay={separators.unhighlight}>
      <View style={styles.itemContainer}>
        {console.log('====> ', index)}
        <Text style={styles.itemStyle}>{item.title}</Text>
      </View>
    </TouchableHighlight>
);

return(
  <SafeAreaView style={{ flex: 1 }}>
    <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={styles.titleStyle}> List of Pro Langs - FlatList </Text>
      <FlatList
      ItemSeparatorComponent={itemSeparator}
      data={DATA}
      renderItem={constructItem}
      />
      </View>
  </SafeAreaView>
);
}

export default App;
