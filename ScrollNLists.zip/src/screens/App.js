
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Alert,
  ScrollView,
  SectionList
} from 'react-native';
import styles from './styles/welcomeStyles';

const App = () => {
  const DATA = [
      {
        title: "Operating System",
        data: [
          "Processes & Threads",
          "Memory Management",
          "CPU Scheduling",
          "Process Synchronization",
          "Deadlock",
        ],
      },
      {
        title: "Computer Network",
        data: [
          "Data Link Layer",
          "Network Layer",
          "Transport Layer",
          "Application Layer",
          "Network Security",
        ],
      },
      {
        title: "DBMS",
        data: [
          "Entity Relationship Model",
          "Normalisation",
          "Transaction and Concurrency Control",
          "Indexing, B and B+ trees",
          "File Organization",
        ],
      },
    ];

    const itemSeparator = ()=>(
      <View style={styles.itemSeparator} />
    );

    const createSubListItem = ({item})=>(
      <View style={styles.row}>
        <Text style={styles.rowText}>{item}</Text>
      </View>
    );

    const createListHeader = ({ section: { title } }) => (
      <Text style={styles.header}>{title}</Text>
    );

    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={[styles.titleStyle, {color: '#000'}]}> Section List Demo </Text>
      <SectionList
        sections={DATA}
        ItemSeparatorComponent={itemSeparator}
        renderItem={createSubListItem}
        renderSectionHeader={createListHeader}/>
      </View>
      </SafeAreaView>
      );
}

export default App;
