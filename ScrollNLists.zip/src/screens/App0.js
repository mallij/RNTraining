
import React from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Alert,
  ScrollView
} from 'react-native';
import styles from './styles/welcomeStyles';

const App = () => {
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ width: '100%', flexDirection: 'column', alignItems: 'center'}}>
      <Text style={styles.titleStyle}> Alert & Model Demo </Text>
      <ScrollView>
      <Text style={styles.titleStyle}> Alert & Model Demo 1 </Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 2 </Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 3 </Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 4</Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 3 </Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 4</Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 3 </Text>
      <Text style={styles.titleStyle}> Alert & Model Demo 4</Text>
      </ScrollView>
      <ScrollView>

        <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity = {1}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          Show Modal 2
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity = {1}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          Show Alert 3
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity = {1}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          Show Modal 3
          </Text>
        </TouchableOpacity>
      </ScrollView>
      </View>

      </SafeAreaView>
      );
}

export default App;
