import React, {useState} from 'react';
import { Button, View } from 'react-native';

export default function App() {
  const [number, setValue] = useState(0);
  const [number2, setValue2] = useState(0);
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>

      <Button onPress={() => setValue(number + 1) />

      <Button onPress={() => setValue2(number2 - 1) />

    </View>
  );
}
