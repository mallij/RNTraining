/**
* Sample React Native App
* https://github.com/facebook/react-native
*
* @format
* @flow strict-local
*/

import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Button,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback
} from 'react-native';

  import welcomeStyles from './styles/welcomeStyles';
  import PrimaryButton from '../components/PrimaryButton';
  import multiplyNumbers, {addNumbers} from './values';

  const Welcome = () => {
    var counter = 1;

    const incrementCounter = () => {
      console.log('BEFORE=====> ', counter);
      counter = counter + 1;
      console.log('AFTER=====> ', counter);
    }

    const incrementCounter2 = () => {
      console.log('BEFORE=====> ', counter);
      counter = counter + 1;
      console.log('AFTER=====> ', counter);
    }

    const incrementCounter3 = () => {
      console.log('BEFORE=====> ', counter);
      counter = counter + 1;
      console.log('AFTER=====> ', counter);
    }

    const obj = {obj1: incrementCounter, obj2:incrementCounter2};

    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={welcomeStyles.titleStyle}> Basic UI Elements  </Text>
      <Text style={welcomeStyles.borderedTextStyle}> {counter} </Text>

      <PrimaryButton
      onClick={obj}
      label='Click - Blue'
      bgColor='#2BB4CD'/>

      <PrimaryButton
      onClick={incrementCounter2}
      label='Click - Green'
      bgColor='#077A06'/>

      <PrimaryButton
      onClick={incrementCounter3}
      label='Click - Yellow'
      bgColor='#A2A644'/>

      <Button
      title='Add Numbers'
      color='blue'
      onPress={() => {addNumbers(3,4)}} />

      <Button
      title='Multiply Numbers'
      color='blue'
      onPress={() => {multiplyNumbers(3,4)}} />

      </View>
      </SafeAreaView>
      );
    }

export default Welcome;
