
import React, {useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';

const Profile = (props) => {

  // ComponentDidMount
  useEffect(() => {
    // Code to execute when the compoent is loaded for the first time
    // console.log('Welcome - DID MOUNT', num);
    console.log('Home - DID MOUNT');
  }, []);

  // componentWillUnmount
  useEffect(() => {
    return () => {
      console.log('Home - WILL UNMOUNT');
    };
  }, []);

    return(
      <SafeAreaView style={{ flex: 1, marginTop: 20 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      {console.log('Home - RENDER')}
      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => props.navigation.navigate('MyProfile')}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Increment
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => props.navigation.navigate('MyProfile')}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Decrement
        </Text>
      </TouchableOpacity>
      </View>
      </SafeAreaView>
      );
}

export default Profile;
