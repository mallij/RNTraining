
import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Pressable
} from 'react-native';
import styles from './styles/welcomeStyles';

const Welcome = (props) =>{
    const [number, setNumber] = useState(0);
    const [number2, setNumber2] = useState(100);
    // var num = 10;
    // ComponentDidMount
    useEffect(() => {
      // Code to execute when the compoent is loaded for the first time
      // console.log('Welcome - DID MOUNT', num);
      console.log('Welcome - DID MOUNT');
    }, []);

    // ComponentDidUpdate - for number 1
    useEffect(() => {
      console.log('Welcome - DID UPDATE - Numbe 1');
    }, [number]);

    // ComponentDidUpdate - for number 2
    useEffect(() => {
      console.log('Welcome - DID UPDATE - Number 2');
    }, [number2]);

    return(
      <SafeAreaView style={{ flex: 1, marginTop: 10 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      {console.log('Welcome - RENDER')}
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() =>
      {
        setNumber(number+1);
        props.navigation.navigate('MyHome');
      }
      }
        >
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Go Home
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() =>
      {
        setNumber2(number2+100);
        // props.navigation.navigate('MyHome');
      }
      }
        >
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Add 100
        </Text>
      </TouchableOpacity>
      </View>
      </SafeAreaView>
      );
}

export default Welcome;
