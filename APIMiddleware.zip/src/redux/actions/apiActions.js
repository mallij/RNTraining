import { LOAD_DATA_ERROR, LOAD_DATA_IN_PROGRESS, LOAD_DATA_SUCCESS } from '../../constants/constants';

export const apiSuccess = (response) =>{
  return {
    type: LOAD_DATA_SUCCESS,
    payload: response
  };
}

export const apiError = (error) =>{
  return {
    type: LOAD_DATA_ERROR,
    payload: error
  };
}

export const apiStart = (response) =>{
  return {
    type: LOAD_DATA_IN_PROGRESS
  };
}
