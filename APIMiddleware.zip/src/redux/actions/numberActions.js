import { STORE_NUMBER, STORE_NAME } from '../../constants/constants';

export const storeNumber = (number) =>{
  return {
    type: STORE_NUMBER,
    payload: number
  };
}
