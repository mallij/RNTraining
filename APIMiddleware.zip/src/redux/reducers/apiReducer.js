import {
  LOAD_DATA_ERROR,
  LOAD_DATA_IN_PROGRESS,
  LOAD_DATA_SUCCESS
} from '../../constants/constants';

const initialState = {
   data: {},
   isLoaderVisible: false,
   error: ''
};

const apiReducer = (state = initialState, action) => {
  switch (action.type) {
       case LOAD_DATA_IN_PROGRESS: {
           return {
               ...state,
               isLoaderVisible: true,
               error:''
           };
       }
       case LOAD_DATA_SUCCESS: {
           return {
               ...state,
               data: action.payload,
               isLoaderVisible: false,
               error:''
           }
       }
       case LOAD_DATA_ERROR: {
           return {
               ...state,
               isLoaderVisible: false,
               error: action.payload
           };
       }
       default: {
           return state;
       }
   }
}
export default apiReducer;
