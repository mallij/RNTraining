import {
  STORE_NUMBER,
  INCREMENT_NUMBER,
  DECREMENT_NUMBER
} from '../../constants/constants';

const initialState = {
  counter: 0,
  marks: 40
};

function numberReducer(state = initialState, action) {
  switch (action.type) {
    case STORE_NUMBER:
    const tempState = {...state, counter: action.payload};
    console.log(tempState);
      return tempState;

    case INCREMENT_NUMBER:
    const tempState2 = {...state, counter: state.counter+1};
    console.log(tempState2);
      return tempState2;

    case DECREMENT_NUMBER:
      return {...state, counter: state.counter-1};

    default:
      return state;
  }
}
export default numberReducer;
