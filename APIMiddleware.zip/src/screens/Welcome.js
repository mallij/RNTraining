
import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Pressable,
  Modal,
  ActivityIndicator
} from 'react-native';
import styles from './styles/welcomeStyles';

import { STORE_NUMBER, STORE_NAME,
   LOAD_DATA_IN_PROGRESS, LOAD_DATA_SUCCESS, LOAD_DATA_ERROR } from '../constants/constants';

import { apiError, apiStart, apiSuccess } from '../redux/actions/apiActions';

import {useSelector, useDispatch } from 'react-redux';

const Welcome = (props) =>{
  const data = useSelector((store) => store.rApi.data);
  const error = useSelector((store) => store.rApi.error);
  const modalVisible = useSelector((store) => store.rApi.isLoaderVisible);
  const dispatch = useDispatch();

  const URL = 'https://jsonplaceholder.typicode.com/todos/1';
  // Calling API with async - await
  const callAPIWithFetch = async() =>{
    try{
      dispatch(apiStart());
      const response = await fetch(URL);
      const jsonResponse = await response.json();
      dispatch(apiSuccess(jsonResponse));
    }
    catch(error){
      console.log('Error =====> ', error.message);
      dispatch(apiError(error.message));
    }
  }

    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={styles.titleStyle}> Api Calls - fetch </Text>

          <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity = {1}
          onPress={() => callAPIWithFetch()}>
            <Text
            style={{textAlign: 'center', fontWeight: 'bold'}}>
            Call API - Using fetch
            </Text>
          </TouchableOpacity>
          <Text style={styles.titleStyle}> {JSON.stringify(data)} </Text>
          <Text style={styles.titleStyle}> {error} </Text>

          <Modal
          animationType="fade"
          transparent={true}
          visible={modalVisible}>
            <View style={styles.centeredView}>
              <View style={styles.modalView}>
              <ActivityIndicator size="small" color="#0000ff" />
              <Text style={styles.titleStyle}>Please wait...</Text>
              </View>
              </View>
          </Modal>
      </View>
      </SafeAreaView>
      );
}

export default Welcome;
