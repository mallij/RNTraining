import React from 'react';
import { Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import thunk from 'redux-thunk';

import {createStore, combineReducers, applyMiddleware} from 'redux';
import { Provider } from 'react-redux';

import numberReducer from '../redux/reducers/numberReducer';
import nameReducer from '../redux/reducers/nameReducer';
import apiReducer from '../redux/reducers/apiReducer';

import Welcome from './Welcome';
import Home from './Home';
import Profile from './Profile';
import WelcomeClass from './WelcomeClass';

const Stack = createNativeStackNavigator();

const allReducers = combineReducers({rApi: apiReducer, rNumber: numberReducer, rName:nameReducer});

const myStore = createStore(allReducers, applyMiddleware(thunk));

// const myStore = createStore(numberReducer);

function App() {
  return (
    <Provider store={myStore}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="WelcomePage"
          screenOptions={{
          headerStyle: { backgroundColor: '#707F0A'},
          headerTitleStyle: {color: 'black'}
        }}>
          <Stack.Screen name="WelcomePage" component={Welcome}/>
          <Stack.Screen name="MyHome" component={Home}/>
          <Stack.Screen name="MyProfile" component={Profile}/>
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}

export default App;
