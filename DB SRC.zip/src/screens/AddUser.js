/*Screen to register the user*/
import React, {useState, useEffect} from 'react';
import { View, ScrollView, Alert } from 'react-native';
import CustomTextBox from '../components/CustomTextBox';
import PrimaryButton from '../components/PrimaryButton';
import Realm from 'realm';
let realm;

const AddUser = (props) => {
  useEffect(() => {
    realm = new Realm({ path: 'UserInfo.realm' });
  }, []);

  var name = '', phone = '', address = '';

  registerUser = () => {
    if (name) {
      if (phone) {
        if (address) {
          realm.write(() => {
            var ID =
              realm.objects('User').sorted('userId', true).length > 0
                ? realm.objects('User').sorted('userId', true)[0]
                    .userId + 1
                : 1;
            realm.create('User', {
              userId: ID,
              userName: name,
              userPhone: phone,
              userAddress: address,
            });
            Alert.alert(
              'Success',
              'You are registered successfully',
              [
                {
                  text: 'Ok',
                  onPress: () => props.navigation.navigate('HomeScreen'),
                },
              ],
              { cancelable: false }
            );
          });
        } else {
          alert('Please fill Address');
        }
      } else {
        alert('Please fill Contact Number');
      }
    } else {
      alert('Please fill Name');
    }
  };

    return (
      <View style={{ backgroundColor: 'white', flex: 1, alignItems: 'center' }}>
        <ScrollView keyboardShouldPersistTaps="handled">
            <CustomTextBox
              placeholder="Enter Name"
              onChangeText={(userName) => name = userName}
            />
            <CustomTextBox
              placeholder="Enter Contact No"
              onChangeText={(contact) => phone = contact}
              maxLength={10}
              keyboardType="numeric"
            />
            <CustomTextBox
              placeholder="Enter Address"
              onChangeText={(addressText) => address = addressText}
              maxLength={225}
              numberOfLines={5}
              multiline={true}
              style={{ textAlignVertical: 'top' }}
            />
            <PrimaryButton
              label="Submit"
              customClick={registerUser}
            />
        </ScrollView>
      </View>
    );
}

export default AddUser;
