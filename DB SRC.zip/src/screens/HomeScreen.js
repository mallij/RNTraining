/*Home Screen With buttons to navigate to diffrent options*/
import React, {useEffect} from 'react';
import { View } from 'react-native';
import PrimaryButton from '../components/PrimaryButton';
import Label from '../components/Label';
import Realm from 'realm';
let realm;

const HomeScreen = (props) => {

  useEffect(() => {
    realm = new Realm({
      path: 'UserInfo.realm', // Name of our app database
      schema: [
        {
          name: 'User',
          properties: {
            userId: { type: 'int', default: 0 },
            userName: 'string',
            userPhone: 'string',
            userAddress: 'string',
          },
        }
      ],
    });
  }, []);

  // const { navigation } = props;
  const gotoNext = props.navigation.navigate;

    return (
      <View
        style={{
          flex: 1,
          backgroundColor: 'white',
          flexDirection: 'column',
          alignItems: 'center'
        }}>
        <Label text="RealM Database Demo" />

        <PrimaryButton
          label="Register"
          customClick={() => gotoNext('AddUser')}
        />
        <PrimaryButton
          label="Update"
          customClick={() => gotoNext('UpdateUser')}
        />
        <PrimaryButton
          label="View"
          customClick={() => gotoNext('SearchUser')}
        />
        <PrimaryButton
          label="View All"
          customClick={() => gotoNext('AllUsers')}
        />
        <PrimaryButton
          label="Delete"
          customClick={() => gotoNext('DeleteUser')}
        />
      </View>
    );
}

export default HomeScreen;
