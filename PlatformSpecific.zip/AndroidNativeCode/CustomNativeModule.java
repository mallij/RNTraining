package com.platforspecific;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class CustomNativeModule extends ReactContextBaseJavaModule {
    private SharedPreferences preferences;
    CustomNativeModule(ReactApplicationContext context) {
        super(context);
        preferences = context.getSharedPreferences("nativeprefs", Context.MODE_PRIVATE);
    }

    @ReactMethod
    public void storeData(String key, String value){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.apply();
        System.out.println("=======> Saved");
    }

    @ReactMethod
    public void getData(String key, Callback callback){
        String strValue = preferences.getString(key, "No Value");
        callback.invoke(strValue);
    }

    @NonNull
    @Override
    public String getName() {
        return "MyNativeModule";
    }
}
