
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  Pressable,
  Platform
} from 'react-native';
import styles from './styles/welcomeStyles';

const Welcome = (props) => {
  var data;
  const osName = Platform.OS;
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={styles.titleStyle}> Platform Specific Impl </Text>

        <Text style={(osName == 'android')? styles.titleAndroidStyle : styles.titleIOSStyle}> {osName} - {Platform.Version} </Text>
        <Text style={styles.titleStyle}> {osName} - {Platform.Version} </Text>

        {(osName == 'android')?
          (<TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity = {1}
          onPress={() => props.navigation.navigate('MyHome', {info: data, amount: 100})}>
            <Text
            style={{textAlign: 'center', fontWeight: 'bold'}}>
            Go Home
            </Text>
          </TouchableOpacity>) :

          (<Pressable
            style={styles.buttonStylePressable}
          onPress={() => props.navigation.navigate('MyHome', {info: data, amount: 100})}>
            <Text>I'm pressable!</Text>
          </Pressable>)
        }

        <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity = {1}
        onPress={() => props.navigation.navigate('MyProfile')}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          Go Profile
          </Text>
        </TouchableOpacity>

      </View>
      </SafeAreaView>
      );
}

export default Welcome;
