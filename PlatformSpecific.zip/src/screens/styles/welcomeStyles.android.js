import { StyleSheet, Platform } from 'react-native';

const welcomeStyles = StyleSheet.create(
  {
    titleStyle: {
      color: '#9EB11F',
      fontSize: 20,
      fontWeight: 'bold'
    },
    titleAndroidStyle: {
      color: '#9EB11F',
      fontSize: 20,
      fontWeight: 'bold'
    },
    titleIOSStyle: {
      color: '#20220F',
      fontSize: 20,
      fontWeight: 'bold'
    },
    messageStyle: {
      color: '#000000',
      fontSize: 18
    },
    erroMessageStyle: {
      color: '#F82C22',
      fontSize: 18
    },
    borderedTextStyle:{
      margin: 20,
      padding: 10,
      width: 200,
      borderColor: "#000000",
      borderWidth: 2,
    },
    borderedTextErrorStyle:{
      margin: 20,
      padding: 10,
      width: 200,
      borderColor: "#F82C22",
      borderWidth: 2
    },
    buttonStyle:{
      padding: 10,
      borderColor: 'black',
      borderWidth: 2,
      backgroundColor:'#2BB4CD',
      margin: 5,
      width: 150,
      borderRadius: 5
    },
    buttonStyleAndroid:{
      padding: 10,
      borderColor: 'black',
      borderWidth: 2,
      backgroundColor:'#12A50A',
      margin: 5,
      width: 150,
      borderRadius: 5
    },
    buttonStyleIOS:{
      padding: 10,
      borderColor: 'black',
      borderWidth: 2,
      backgroundColor:'#0F7D76',
      margin: 5,
      width: 150,
      borderRadius: 5
    },
    centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  buttonStylePressable:{
    padding: 10,
    borderColor: 'black',
    borderWidth: 2,
    backgroundColor:'#2BB4CD',
    margin: 5,
    borderRadius: 5,
    textAlign: 'center'
  },
  }
);

export default welcomeStyles;
