
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';

const Profile = (props) => {
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />

      <Text style={styles.titleStyle}> Welcome to iOS - Apple </Text>
      <TouchableOpacity
      style={styles.buttonStyleIOS}
      activeOpacity = {1}
      onPress={() => props.navigation.navigate('MyProfile')}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Profile
        </Text>
      </TouchableOpacity>
      </View>
      </SafeAreaView>
      );
}

export default Profile;
