import React from 'react';
import { Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Welcome from './Welcome';
import Home from './Home';
import Profile from './Profile';

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="WelcomePage"
      screenOptions={{ title: 'My App',
      headerStyle: { backgroundColor: '#707F0A'},
      headerTitleStyle: {color: 'black'} }}>

        <Stack.Screen name="WelcomePage" component={Welcome} options={{ title: 'Welcome Screen'}}/>

        <Stack.Screen name="MyHome" component={Home} />
        <Stack.Screen name="MyProfile" component={Profile} options={{ title: 'Profile Screen'}}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
