//
//  RCTCalendarModule.h  RCTMyNativeModule.m
//  PlatforSpecific
//
//  Created by Mallikarjuna J on 02/09/22.
//

#import <Foundation/Foundation.h>
// RCTCalendarModule.m
#import "RCTMyNativeModule.h"
#import <React/RCTLog.h>
@implementation RCTMyNativeModule

// To export a module named RCTCalendarModule
RCT_EXPORT_MODULE(MyNativeModule);
RCT_EXPORT_METHOD(storeData:(NSString *)key value:(NSString *)value)
{
  RCTLogInfo(@"Pretending to create an event %@ at %@", key, value);
}
@end

