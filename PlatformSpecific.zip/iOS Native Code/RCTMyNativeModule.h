//
//  RCTMyNativeModule.h
//  PlatforSpecific
//
//  Created by Mallikarjuna J on 02/09/22.
//

#ifndef RCTMyNativeModule_h
#define RCTMyNativeModule_h

//  RCTCalendarModule.h
#import <React/RCTBridgeModule.h>
@interface RCTMyNativeModule : NSObject <RCTBridgeModule>
@end

#endif /* RCTMyNativeModule_h */
