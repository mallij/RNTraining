import React, { Component } from 'react';
import { Text, View,Button, TextInput, TouchableOpacity } from 'react-native'
import {connect} from 'react-redux';
import {increaseBurgerAction,decreaseBurgerAction}  from '../Redux/index';
import styles from './styles/welcomeStyles';
import { STORE_NUMBER, STORE_NAME } from '../constants/constants';
import { storeNumber } from '../redux/actions/numberActions';

class ReduxInClass extends Component {
    render() {
      var number = 0;
        return (
            <View style={{justifyContent:'center',alignItems:'center'}}>
                <View style={{marginVertical:50}}>
                <TextInput
                onChangeText={(text) => number = text}
                style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
                placeholder={'Enter Number'} />
                <TouchableOpacity
                style={styles.buttonStyle}
                activeOpacity = {1}
                onPress={() =>
                {
                  console.log('Number : ', number);

                  // Creating action object
                  // const action = {
                  //   type: STORE_NUMBER,
                  //   payload: number
                  // };

                  this.props.storeNumber(number);

                  this.props.navigation.navigate('MyHome');
                }
                }
                  >
                  <Text
                  style={{textAlign: 'center', fontWeight: 'bold'}}>
                  Save Number
                  </Text>
                </TouchableOpacity>
                </View>
            </View>
        )
    }
}

const mapStateToProps=(state)=>{
  return{
      counterValue:state.counter
  }
}

const mapDispatchToProps=(dispatch)=>{
  return{
      storeNumber:(number)=>{dispatch({type:STORE_NUMBER, payload: number})}
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(ReduxInClass);
