
import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';
import { useSelector, useDispatch } from 'react-redux';

const Profile = (props) => {
    const counterValue = useSelector((store) => store.counter);

    return(
      <SafeAreaView style={{ flex: 1, marginTop: 20 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => props.navigation.navigate('MyProfile')}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Increment
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => props.navigation.navigate('MyProfile')}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Decrement
        </Text>
      </TouchableOpacity>

      <Text
      style={{textAlign: 'center', fontWeight: 'bold'}}>
      {counterValue}
      </Text>
      </View>
      </SafeAreaView>
      );
}

export default Profile;
