
import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Pressable
} from 'react-native';
import styles from './styles/welcomeStyles';

import { STORE_NUMBER, STORE_NAME } from '../constants/constants';
import { storeNumber } from '../redux/actions/numberActions';

import { useDispatch } from 'react-redux';

const Welcome = (props) =>{
    var number = 0;
    var name = '';
    const [value, setValue] = useState(0);
    const dispatch = useDispatch();

    return(
      <SafeAreaView style={{ flex: 1, marginTop: 10 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />

      <TextInput
      onChangeText={(text) => number = text}
      style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
      placeholder={'Enter Number'} />

      <TextInput
      onChangeText={(text) => name = text}
      style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
      placeholder={'Enter Name'} />

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() =>
      {
        console.log('Number : ', number);
        setValue(value+1);
        // Creating action object
        // const action = {
        //   type: STORE_NUMBER,
        //   payload: number
        // };

        // const action = {
        //   type: STORE_CREDENTIALS,
        //   payload: {userId: email, pwd: password}
        // };

        // Creating action object
        // const action2 = {
        //   type: STORE_NAME,
        //   payload: name
        // };
        //
        // dispatch(action);
        // // dispatch(storeNumber(number));
        // dispatch(action2);

        props.navigation.navigate('MyHome');
      }
      }
        >
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Go Home
        </Text>
      </TouchableOpacity>
      <Text style={styles.titleStyle}> {} </Text>
      </View>
      </SafeAreaView>
      );
}

export default Welcome;
