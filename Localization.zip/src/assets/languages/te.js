const telugu = {
  first:"మీరు ఎలా ఉన్నారు ?",
  second:"నేను బాగానే ఉన్నాను",
  selectLanguage: 'భాషను ఎంచుకోండి',
  next: 'తరువాత'
};

export default telugu;
