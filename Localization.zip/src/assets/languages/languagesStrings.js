import LocalizedStrings from 'react-native-localization';
import english from './en';
import french from './fr';
import marati from './ma';
import hindi from './hi';
import telugu from './te';

const languageStrings = new LocalizedStrings({
  ma: marati,
  hi: hindi,
  en: english,
  fr: french,
  te: telugu
});

export default languageStrings;
