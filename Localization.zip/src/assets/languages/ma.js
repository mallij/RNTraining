const marati = {
  first:"तू कसा आहेस ?",
  second:"मी ठीक आहे ?",
  selectLanguage: 'भाषा निवडा',
  next: 'पुढे'
};

export default marati;
