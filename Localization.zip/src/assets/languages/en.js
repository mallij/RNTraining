const english = {
  first:"How are You ?",
  second:"I am fine ",
  selectLanguage: 'Select Language',
  next: 'Next'
};

export default english;
