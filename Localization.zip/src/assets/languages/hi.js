const hindi = {
  first:"क्या हाल है ?",
  second:"मैं ठीक हूँ ?",
  selectLanguage: 'भाषा चुने',
  next: 'अगला'
};

export default hindi;
