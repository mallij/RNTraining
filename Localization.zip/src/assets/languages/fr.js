const french = {
  first:"comment allez vous",
  second:"je vais bien",
  nextLabel: 'Next',
  selectLanguage: 'Choisir la langue',
  next: 'Prochaine'
};

export default french;
