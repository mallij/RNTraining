
import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Pressable
} from 'react-native';
import styles from './styles/welcomeStyles';
import languageStrings from '../assets/languages/languagesStrings';

const Welcome = (props) => {

  useEffect(() => {
    // to get the language code from the device settings
   const deviceLanguage = languageStrings.getInterfaceLanguage();
   languageStrings.setLanguage(deviceLanguage);
   console.log('Lang Device ===> ', deviceLanguage);
 }, []);

  var data;
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={styles.titleStyle}> Localization Demo </Text>
        <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity = {1}
        onPress={() => props.navigation.navigate('Select')}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          {languageStrings.selectLanguage}
          </Text>
        </TouchableOpacity>
      </View>
      </SafeAreaView>
      );
}

export default Welcome;
