import React, {useEffect, useState} from 'react';
import {
  SafeAreaView,
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity
} from 'react-native';
import languageStrings from '../assets/languages/languagesStrings';
import style from './styles/welcomeStyles';

const SelectLanguage = (props) => {

  const [buttonLabel, setButtonLabel] = useState('');

  const lang = [
    {langCode: 'hi', langName: 'हिन्दी'},
    {langCode: 'ma', langName: 'मराठी'},
    {langCode: 'en', langName: 'English'},
    {langCode: 'fr', langName: 'française(feminine)'},
    {langCode: 'te', langName: 'తెలుగు'}
  ];

  const settext = (value) => {
    // To change the Locale / Language of the app we use setLanguage from LocalizedStrings
    languageStrings.setLanguage(value);
    props.navigation.navigate('UseLangauge', {selectedLanguage: value});
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={styles.container}>
        <Text style={styles.headingStyle}>
          Please Select Preferred Language
        </Text>
        <Image
          source={{
            uri:
              'https://raw.githubusercontent.com/AboutReact/sampleresource/master/language.png',
          }}
          style={styles.imageStyle}
        />

        <ScrollView style={{marginTop: 30, width: '80%'}}>
          {lang.map((item, key) => (
            <View style={styles.elementContainer} key={key}>
              <Text
                onPress={() => settext(item.langCode)}
                style={styles.textStyle}>
                {item.langName}
              </Text>
              <View style={styles.saparatorStyle} />
            </View>
          ))}
        </ScrollView>
        <Text
          style={{
            fontSize: 18,
            textAlign: 'center',
            color: 'grey',
          }}>
          Example of Localization in React Native
         (Multi Language App)
        </Text>
        <Text
          style={{
            fontSize: 16,
            textAlign: 'center',
            color: 'grey',
          }}>
          www.aboutreact.com
        </Text>

        <TouchableOpacity
        style={style.buttonStyle}
        activeOpacity = {1}
        onPress={() => props.navigation.navigate('UseLangauge', {selectedLanguage: 'Nothing'})}>
          <Text
          style={{textAlign: 'center', fontWeight: 'bold'}}>
          {languageStrings.next}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  headingStyle: {
    color: '#191919',
    fontSize: 25,
    textAlign: 'center',
  },
  imageStyle: {
    width: 64,
    height: 64,
    marginTop: 30,
  },
  elementContainer: {
    width: '100%',
    marginTop: 30,
    alignItems: 'center',
  },
  textStyle: {
    color: '#191919',
    fontSize: 25,
  },
  saparatorStyle: {
    height: 0.5,
    width: '60%',
    backgroundColor: '#C2C2C2',
    marginTop: 10,
  },
});

export default SelectLanguage;
