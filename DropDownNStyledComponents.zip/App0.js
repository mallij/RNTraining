/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  TouchableOpacity
} from 'react-native';

import { Dropdown } from 'react-native-element-dropdown';

const App = () => {

  const [value, setValue] = useState('');
  const [dept, setDept] = useState({});
  const [index, setIndex] = useState(-1);
  const [isFocus, setIsFocus] = useState(false);

  const data = [
  { label: 'Select Department', deptId: '000' },
  { label: 'Admin', deptId: '121' },
  { label: 'Security', deptId: '122' },
  { label: 'Finance', deptId: '123' },
  { label: 'Recruitment', deptId: '124' },
  { label: 'HR', deptId: '125' },
  { label: 'Marketing', deptId: '126' },
  { label: 'Sales', deptId: '127' }
  ];

  const validateData = () =>
  {
    if(index == '000' || index == -1)
    {
      console.log('Please select a department');
    }
    else {
        console.log('Department selected ', dept);
    }
  }
  return (
    <SafeAreaView style={{flex:1,}}>
      <ScrollView>
        <View
          style={styles.container}>
          <Text>Dropdown N Styled Components</Text>
          <Dropdown
          style={[styles.dropdown, isFocus && { borderColor: 'blue' }]}
          placeholderStyle={styles.placeholderStyle}
          data={data}
          labelField="label"
          valueField="deptId"
          placeholder={(value == '') ? 'Select Department' : value}
          value={value}
          onFocus={() => setIsFocus(true)}
          onBlur={() => setIsFocus(false)}
          onChange={(item, index) => {
            setValue(item.label);
            setDept(item);
            setIsFocus(false);
            setIndex(index);
            console.log('=====> ', index);
          }}
      />

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => validateData()}>
        <Text
        style={styles.text}>
          Verify Data
        </Text>
        </TouchableOpacity>

        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex:1,
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
  dropdown: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 0.5,
    borderRadius: 8,
    marginVertical: 30,
    paddingHorizontal: 8,
  },
  icon: {
    marginRight: 5,
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  buttonStyle: {
    padding: 10,
    borderColor: 'black',
    borderWidth: 2,
    backgroundColor:'#f05555',
    marginVertical: 10,
    width: 150,
    borderRadius: 5,
    alignSelf: 'center'
  },
  text: {
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
  },
});

export default App;
