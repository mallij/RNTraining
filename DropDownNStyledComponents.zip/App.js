/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, {useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity
} from 'react-native';

import { Dropdown } from 'react-native-element-dropdown';

import styled from 'styled-components/native';
import SplashScreen from 'react-native-splash-screen';

const CustomText = styled.Text`
  color: #000000;
  text-align: center;
  font-weight: bold;
  font-size: 22px;
`;

const CustomButton = styled.TouchableOpacity`
  padding: 10px;
  border-color: black;
  border-width: 2px;
  background-color:#f05555;
  margin-top: 10px;
  margin-bottom: 10px;
  width: 150px;
  border-radius: 5px;
  align-self: center;
`;

const Container = styled.View`
  flex:1;
  margin-top: 32px;
  margin-bottom: 32px;
  padding-left: 24px;
  padding-right: 24px;
`;

const App = () => {

  useEffect(() => {
    SplashScreen.hide();
  }, []);
  const validateData = () => {
    console.log('Button Clicked');
  }
  return (
    <SafeAreaView style={{flex:1,}}>
      <ScrollView>
        <Container>
          <Text style={styles.text}>Styled Components</Text>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => console.log('Button Clicked')}>
        <Text
        style={styles.buttonTextStyle}>
          Verify Data
        </Text>
        </TouchableOpacity>

        <CustomButton
        activeOpacity = {1}
        onPress={validateData}>
          <Text
          style={styles.buttonTextStyle}>
            Verify Data
          </Text>
          </CustomButton>

        <CustomText>End of Styled Components Demo</CustomText>
        <Text style={styles.textStyle}>End of Styled Components Demo</Text>

        </Container>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex:1,
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
  dropdown: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 0.5,
    borderRadius: 8,
    marginVertical: 30,
    paddingHorizontal: 8,
  },
  icon: {
    marginRight: 5,
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  buttonStyle: {
    padding: 10,
    borderColor: 'black',
    borderWidth: 2,
    backgroundColor:'#f05555',
    marginVertical: 10,
    width: 150,
    borderRadius: 5,
    alignSelf: 'center'
  },
  text: {
    color: '#000',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 30
  },
  textStyle: {
    color: '#000',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 22
  },
  buttonTextStyle: {
    color: '#000',
    textAlign: 'center',
    fontSize: 20
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
  },
});

export default App;
