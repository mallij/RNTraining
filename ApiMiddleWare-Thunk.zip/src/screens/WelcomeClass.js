import React, { Component } from 'react';
import { Text, View,Button, TextInput, TouchableOpacity } from 'react-native'
import {connect} from 'react-redux';
import {increaseBurgerAction,decreaseBurgerAction}  from '../Redux/index';
import styles from './styles/welcomeStyles';
import { STORE_NUMBER, INCREMENT_NUMBER } from '../constants/constants';
import { storeNumber } from '../redux/actions/numberActions';

class WelcomeClass extends Component {
    render() {
      var number = 0;
        return (
          <View style={{justifyContent:'center',alignItems:'center'}}>
              <View style={{marginVertical:50}}>
              <TextInput
              onChangeText={(text) => number = text}
              style={{marginVertical: 10, borderWidth:3, borderColor: '#000', padding: 10}}
              placeholder={'Enter Number'} />
              <Text style={styles.titleStyle}> {this.props.counterValue} </Text>
              <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity = {1}
              onPress={() =>
              {
                console.log('Number : ', number);

                // Creating action object
                const action = {
                  type: STORE_NUMBER,
                  payload: parseInt(number)
                };

                this.props.storeNumber(action);

                this.props.navigation.navigate('MyHome');
              }
              }
                >
                <Text
                style={{textAlign: 'center', fontWeight: 'bold'}}>
                Save Number
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity = {1}
              onPress={() =>
              {

                this.props.increaseNumber();

                // this.props.navigation.navigate('MyHome');
              }
              }
                >
                <Text
                style={{textAlign: 'center', fontWeight: 'bold'}}>
                Incement Number
                </Text>
              </TouchableOpacity>
              </View>
          </View>
        )
    }
}

const saveDataInProps=(state)=>{
  return{
      counterValue:state.rNumber.counter,
      marks:state.rNumber.marks,
      name: state.rName.name
  }
}

const mapDispatchToProps=(dispatch)=>{
  return{
      storeNumber:(action)=>{dispatch(action)},
      increaseNumber:() => {dispatch({type:INCREMENT_NUMBER})}
  }
}

export default connect(saveDataInProps, mapDispatchToProps)(WelcomeClass);
