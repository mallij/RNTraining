import { LOAD_DATA_ERROR, LOAD_DATA_IN_PROGRESS, LOAD_DATA_SUCCESS } from '../../constants/constants';

// Action Creator
export const fetchData = () => dispatch => {
   dispatch({ type: LOAD_DATA_IN_PROGRESS });
   fetch('https://jsonplaceholder.typicode.com/todos/1')
       .then(response => response.json())
       .then((data) => dispatch(apiSuccess(data)))
       .catch((error) => dispatch({ type: LOAD_DATA_ERROR, payload: error.message || 'Unexpected Error!!!' }));
};

// Action
export const apiSuccess = (response) =>{
  return {
    type: LOAD_DATA_SUCCESS,
    payload: response
  };
}
