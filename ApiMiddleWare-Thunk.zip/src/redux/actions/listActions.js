import {
  GET_PAGE_LIST,
  LOAD_USERS_LOADING,
  LOAD_USERS_SUCCESS,
  LOAD_USERS_ERROR
} from '../../constants/constants';

export const loadUsers = () => dispatch => {
   dispatch({ type: LOAD_USERS_LOADING });
   fetch('https://mocki.io/v1/d4867d8b-b5d5-4a48-a4ab-79131b5809b8')
       .then(response => response.json())
       .then(
           data => dispatch({ type: LOAD_USERS_SUCCESS, payload:data }),
           error => dispatch({ type: LOAD_USERS_ERROR, error: error.message || 'Unexpected Error!!!' })
       )
};

export function setPageList(pageList) {
  return {
    type: LOAD_USERS_SUCCESS,
    payload: pageList,
  };
}

export function getPageList() {
  console.log("<=== 1 ===>");
  return async (dispatch) => {
    console.log("<=== 2 ===>");
    try {
      const apiReq = await fetch('https://mocki.io/v1/d4867d8b-b5d5-4a48-a4ab-79131b5809b8');
      const jsonData = await apiReq.json();
      await dispatch(setPageList(jsonData));
    } catch (error) {
      console.error(error);
    }
  };
}
