import {
  STORE_NAME
} from '../../constants/constants';

const initialState = {
  name : 'react'
};

function nameReducer(state = initialState, action) {
  switch (action.type) {
    case STORE_NAME:
      return {...state, name: action.payload};

    default:
      return state;
  }
}
export default nameReducer;
