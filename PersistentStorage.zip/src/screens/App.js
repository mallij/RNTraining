import React from 'react';
import { Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Welcome from './Welcome';
import Home from './Home';

const Stack = createNativeStackNavigator();

function App() {
  return (
      <NavigationContainer>
        <Stack.Navigator initialRouteName="WelcomePage"
          screenOptions={{
          headerStyle: { backgroundColor: '#707F0A'},
          headerTitleStyle: {color: 'black'}
        }}>
          <Stack.Screen name="WelcomePage" component={Welcome}/>
          <Stack.Screen name="MyHome" component={Home}/>
        </Stack.Navigator>
      </NavigationContainer>
  );
}

export default App;
