
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';
import EncryptedStorage from 'react-native-encrypted-storage';

const Profile = (props) => {
  const [data, setData] = useState({});
  const {username, age} = data;
  const getInfo = async() =>{
    try {
        const session = await EncryptedStorage.getItem("session");

        if (session !== undefined) {
          console.log('=====> ', session);
            setData(JSON.parse(session));
        }
    } catch (error) {
        // There was an error on the native side
    }
  }

    return(
      <SafeAreaView style={{ flex: 1, marginTop: 20 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => getInfo()}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Get Info
        </Text>
      </TouchableOpacity>
      <Text
      style={{textAlign: 'center', fontWeight: 'bold'}}>
      {username} - {age}
      </Text>
      </View>
      </SafeAreaView>
      );
}

export default Profile;
