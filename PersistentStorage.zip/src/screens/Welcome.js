
import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Pressable,
  ActivityIndicator,
  Modal
} from 'react-native';
import styles from './styles/welcomeStyles';
import EncryptedStorage from 'react-native-encrypted-storage';

const Welcome = (props) =>{
  const[visible, setVisibile] = useState(true);
  const storeData = async() => {
    try {
            await EncryptedStorage.setItem("session",
                JSON.stringify({
                    username : "React Native",
                    age : 21,
                })
            );
            // Congrats! You've just stored your first value!
        } catch (error) {
            // There was an error on the native side
        }
  }
    return(
      <SafeAreaView style={{ flex: 1, marginTop: 10 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() =>
      {
        storeData();
        props.navigation.navigate('MyHome');
      }
      }
        >
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Save & Go Home
        </Text>
      </TouchableOpacity>
            {
      // <ActivityIndicator />
      // <ActivityIndicator size="large" />
      // <ActivityIndicator size="small" color="#0000ff" />
      // <ActivityIndicator size="large" color="#00ff00" />
    }

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() =>
      {
        setVisibile(!visible);
        // props.navigation.navigate('MyHome');
      }
      }
        >
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Just Go Home
        </Text>
      </TouchableOpacity>
      <Modal
        animationType="slide"
        transparent={true}
        visible={visible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setVisibile(!visible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <ActivityIndicator size="large" color="#00ff00" />
            <Text> Loading... </Text>
          </View>
        </View>
      </Modal>
      </View>
      </SafeAreaView>
      );
}

export default Welcome;
