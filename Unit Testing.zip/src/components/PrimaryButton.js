import React from "react";
import { View, Text, TouchableOpacity } from "react-native";

function PrimaryButton({ styles, children }) {
  return (
    <View>
    <Text>
    {children}
    </Text>
      <TouchableOpacity style={[styles]}>
        <Text>{children}</Text>
      </TouchableOpacity>
    </View>
  );
}
export default PrimaryButton;
