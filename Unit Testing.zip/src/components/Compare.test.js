import Compare from './Compare';

test('If first number is greater than the second or not', () => {
  expect(Compare(4, 3)).not.toBeFalsy();
});
