import React, {useState} from 'react';
import { Text, TextInput, Button } from 'react-native';

const ShoppingList = () => {
  const [groceryItem, setGroceryItem] = useState('');
  const [items, setItems] = useState([]);

  // const arr = [1,2,3];
  // console.log(arr); // [1,2,3]
  // console.log(...arr); // 1,2,3

  const addNewItemToShoppingList = () => {
    setItems([groceryItem, ...items]);
    setGroceryItem('');
  };

  return (
    <>

      <Text>Grocery Shopping</Text>
      <TextInput
        value={groceryItem}
        placeholder="Enter grocery item"
        onChangeText={(text) => setGroceryItem(text)}
      />

      <Button
        title="Add Item"
        onPress={addNewItemToShoppingList}
      />
      {items.map((item) => (
        <Text key={item}>{item}</Text>
      ))}
    </>
  );
}

export default ShoppingList;
