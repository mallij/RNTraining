import React, {useState, useEffect} from 'react';
import ShoppingList from './ShoppingList';

import { render, fireEvent } from '@testing-library/react-native';

test('given empty GroceryShoppingList, user can add an item to it', () => {
  const { getByPlaceholderText, getByText, getAllByText, findBy } = render(
    <ShoppingList />
  );

  // fireEvent is to mock user actions like enter text in text box, clicking a Button

  fireEvent.changeText(getByPlaceholderText('Enter grocery item'),'Apple');
  fireEvent.press(getByText('Add Item'));

  // fireEvent.changeText(getByPlaceholderText('Enter grocery item'),'Mango');
  // fireEvent.press(getByText('Add Item'));

  const groceryList = getAllByText('Apple');
  // const groceryList2 = getAllByText('Mango');

  expect(groceryList).toHaveLength(1); // expect 'Apple' to be on the list
  // expect(groceryList2).toHaveLength(1);
});
