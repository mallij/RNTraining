const sum = require('./sum');

test('Adding two numbers and expecting their sum as output', () => {
  expect(sum(1, 2)).not.toBeNull();
});
