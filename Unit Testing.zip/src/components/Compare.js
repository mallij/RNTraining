export default function Compare(a, b) {
  return a > b;
}
