import React from "react";
import PrimaryButton from "./PrimaryButton";
import renderer from "react-test-renderer";

it(`Checking Primary Button Rendering`, () => {
  const tree = renderer.create(<PrimaryButton styles={{color:'#000'}}>Login</PrimaryButton>);
  expect(tree).toMatchSnapshot();
});
