/*Screen to delete the user*/
import React, {useState, useEffect} from 'react';
import { Button, Text, View, Alert } from 'react-native';
import CustomTextBox from '../components/CustomTextBox';
import PrimaryButton from '../components/PrimaryButton';
import Realm from 'realm';
let realm;
const DeleteUser = (props) => {
  useEffect(() => {
    realm = new Realm({ path: 'UserInfo.realm' });
  }, []);
  const [userId, setUserId] = useState('');

  deleteUser = () => {
    if (userId) {
      realm.write(() => {
        if (
          realm.objects('User').filtered('userId =' + userId)
            .length > 0
        ) {
          realm.delete(
            realm.objects('User').filtered('userId =' + userId)
          );
          var userDetails = realm.objects('User');
          console.log('Updated ===> ',userDetails);
          Alert.alert(
            'Success',
            'User deleted successfully',
            [
              {
                text: 'Ok',
                onPress: () => props.navigation.navigate('HomeScreen'),
              },
            ],
            { cancelable: false }
          );
        } else {
          alert('Given user id is not found');
        }
      });
    } else {
      alert('Please fill User Id');
    }
  };

    return (
      <View style={{ backgroundColor: 'white', flex: 1, alignItems: 'center' }}>
        <CustomTextBox
          placeholder="Enter User Id"
          onChangeText={user_id => setUserId(user_id)}
        />
        <PrimaryButton
          label="Delete User"
          customClick={deleteUser}
        />
      </View>
    );
}

export default DeleteUser;
