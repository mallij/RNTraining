/*Screen to view single user*/
import React, {useState, useEffect, Fragment} from 'react';
import { Text, View, Button, StyleSheet } from 'react-native';
import CustomTextBox from '../components/CustomTextBox';
import PrimaryButton from '../components/PrimaryButton';
import Realm from 'realm';
let realm;

const SearchUser = () => {
  useEffect(() => {
    realm = new Realm({ path: 'UserInfo.realm' });
  }, []);

  const [userId, setUserId] = useState('');
  const [userData, setUserData] = useState('');

  searchUser = () => {
    var userDetails = realm
      .objects('User')
      .filtered('userId =' + userId);
      
    if (userDetails.length > 0) {
      setUserData(userDetails[0]);
    } else {
      alert('No user found');
      setUserData('');
    }
  };

    return (
      <View>
        <CustomTextBox
          placeholder="Enter User Id"
          onChangeText={(user_id) => setUserId(user_id)}
        />
        <PrimaryButton
          label="Search User"
          customClick={searchUser}
        />
        <View style={{ marginLeft: 35, marginRight: 35, marginTop: 10 }}>
          <Text style={styles.idTextStyle}>User Id: {userId}</Text>
          {
            // JSX
            userData != '' ?
            (
              <>
                <Text style={styles.textStyle}>User Name: {userData.userName}</Text>
                <Text style={styles.textStyle}>User Contact: {userData.userPhone}</Text>
                <Text style={styles.textStyle}>User Address: {userData.userAddress}</Text>
              </>
          ) :
            (null)
          }
        </View>
      </View>
    );
}

const styles = StyleSheet.create({
  idTextStyle:{
    color: '#BE5109',
    fontSize: 18,
    fontWeight: 'bold'
  },
  textStyle:{
    color: '#000000',
    fontSize: 18,
    fontWeight: 'bold'
  }
});


export default SearchUser;
