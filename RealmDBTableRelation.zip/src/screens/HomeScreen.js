/*Home Screen With buttons to navigate to diffrent options*/
import React, {useEffect} from 'react';
import { View } from 'react-native';
import PrimaryButton from '../components/PrimaryButton';
import Label from '../components/Label';
import Realm from 'realm';
let realm;

const HomeScreen = (props) => {
  const userTableSchema = {
    name: 'User',
    properties: {
      userId: 'int',
      userName: 'string',
      userPhone: 'string',
      userAddress: 'string',
      deptId: 'int'
    },
    primaryKey:'userId'
  };

  // const userTableSchema = {
  //   name: 'Car',
  //   properties: {
  //     carBrand: 'int',
  //     carModel: 'string',
  //     carYear: 'string'
  //   }
  // };

  const deptTableSchema = {
    name: 'Dept',
    properties: {
      deptId: 'int',
      deptName: 'string'
    },
    primaryKey:'deptId'
  };

  useEffect(() => {
    realm = new Realm({
      path: 'UserInfo.realm', // Name of our app database
      schema: [userTableSchema, deptTableSchema],
    });
    console.log(realm.path);
  }, []);

  // const { navigation } = props;
  const gotoNext = props.navigation.navigate;

    return (
      <View
        style={{
          flex: 1,
          backgroundColor: 'white',
          flexDirection: 'column',
          alignItems: 'center'
        }}>
        <Label text="RealM Database Demo" />

        <PrimaryButton
          label="Register"
          customClick={() => gotoNext('AddUser')}
        />
        <PrimaryButton
          label="Update"
          customClick={() => gotoNext('UpdateUser')}
        />
        <PrimaryButton
          label="View"
          customClick={() => gotoNext('SearchUser')}
        />
        <PrimaryButton
          label="View All"
          customClick={() => gotoNext('AllUsers')}
        />
        <PrimaryButton
          label="Delete"
          customClick={() => gotoNext('DeleteUser')}
        />
      </View>
    );
}

export default HomeScreen;
