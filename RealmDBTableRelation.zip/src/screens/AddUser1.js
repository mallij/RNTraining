/*Screen to register the user*/
import React, {useState, useEffect} from 'react';
import { View, ScrollView, Alert } from 'react-native';
import CustomTextBox from '../components/CustomTextBox';
import PrimaryButton from '../components/PrimaryButton';
import Realm from 'realm';
let realm;

const AddUser = (props) => {
  useEffect(() => {
    realm = new Realm({ path: 'UserInfo.realm' });
  }, []);

  var name = '', phone = '', address = '';

  const data1 = {
    userId: 1,
    userName: 'Ram',
    userPhone: '9090899090',
    userAddress: 'Hyderabad',
    department: {deptId: 121, deptName: 'Finance'}
  };

  const data2 = {
    userId: 2,
    userName: 'Sivan',
    userPhone: '0988090909',
    userAddress: 'Chennai',
    department: {deptId: 131, deptName: 'Admin'}
  };

  const data3 = {
    userId: 3,
    userName: 'Naren',
    userPhone: '7890987890',
    userAddress: 'Banglore',
    department: {deptId: 121, deptName: 'Finance'}
  };

  const data4 = {
    userId: 4,
    userName: 'Sachin',
    userPhone: '9090899090',
    userAddress: 'Mumbai',
    department: {deptId: 141, deptName: 'HR'}
  };

  registerUser = () => {
    try{
      realm.write(() => {
        realm.create('User', data1);
      });
    }catch(error)
    {
      console.log('Error 1 ====> ',error);
    }

    try{
      realm.write(() => {
        realm.create('User', data2);
      });
    }catch(error)
    {
      console.log('Error 2 ====> ',error);
    }

    try{
      realm.write(() => {
        realm.create('User', data3);
      });
    }catch(error)
    {
      console.log('Error 3 ====> ',error);
    }

    try{
      realm.write(() => {
        realm.create('User', data4);
      });
    }catch(error)
    {
      console.log('Error 4 ====> ',error);
    }
  };

  // registerUser = () => {
  //   if (name) {
  //     if (phone) {
  //       if (address) {
  //         realm.write(() => {
  //           var ID =
  //             realm.objects('User').sorted('userId', true).length > 0
  //               ? realm.objects('User').sorted('userId', true)[0]
  //                   .userId + 1
  //               : 1;
  //           realm.create('User', {
  //             userId: ID,
  //             userName: name,
  //             userPhone: phone,
  //             userAddress: address,
  //           });
  //           Alert.alert(
  //             'Success',
  //             'You are registered successfully',
  //             [
  //               {
  //                 text: 'Ok',
  //                 onPress: () => props.navigation.navigate('HomeScreen'),
  //               },
  //             ],
  //             { cancelable: false }
  //           );
  //         });
  //       } else {
  //         alert('Please fill Address');
  //       }
  //     } else {
  //       alert('Please fill Contact Number');
  //     }
  //   } else {
  //     alert('Please fill Name');
  //   }
  // };

    return (
      <View style={{ backgroundColor: 'white', flex: 1, alignItems: 'center' }}>
        <ScrollView keyboardShouldPersistTaps="handled">
            <CustomTextBox
              placeholder="Enter Name"
              onChangeText={(userName) => name = userName}
            />
            <CustomTextBox
              placeholder="Enter Contact No"
              onChangeText={(contact) => phone = contact}
              maxLength={10}
              keyboardType="numeric"
            />
            <CustomTextBox
              placeholder="Enter Address"
              onChangeText={(addressText) => address = addressText}
              maxLength={225}
              numberOfLines={5}
              multiline={true}
              style={{ textAlignVertical: 'top' }}
            />
            <PrimaryButton
              label="Submit"
              customClick={registerUser}
            />
        </ScrollView>
      </View>
    );
}

export default AddUser;
