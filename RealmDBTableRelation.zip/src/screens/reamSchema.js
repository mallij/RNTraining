// import Realm from 'realm';
// import
// export const realm = new Realm({
//   path: 'UserInfo.realm', // Name of our app database
//   schema: [userTableSchema, deptTableSchema],
// });
