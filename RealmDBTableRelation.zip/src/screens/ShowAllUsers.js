/*Screen to view all the user*/
import React, {useState, useEffect} from 'react';
import { FlatList, Text, View, StyleSheet } from 'react-native';
import Realm from 'realm';
let realm;

const ShowAllUsers = () => {
  const [flatListItems, setFlatListItems] = useState([]);
  useEffect(() => {
    realm = new Realm({ path: 'UserInfo.realm' });

    var userDetailsList = realm.objects('User');
    var deptDetails = realm.objects('Dept').filtered(userDetailsList[0].deptId);

    setFlatListItems(userDetailsList);
  }, []);

  ListViewItemSeparator = () => {
    return (
      <View style={{ height: 0.5, width: '100%', backgroundColor: '#000' }} />
    );
  };

  return (
    <View>
      <FlatList
        data={flatListItems}
        ItemSeparatorComponent={ListViewItemSeparator}
        keyExtractor={(item) => item.userId}
        renderItem={({ item }) => (
          <View style={{ backgroundColor: 'white', padding: 20 }}>
            <Text style={styles.idTextStyle}>Id: {item.userId}</Text>
            <Text style={styles.textStyle}>Name: {item.userName}</Text>
            <Text style={styles.textStyle}>Contact: {item.userPhone}</Text>
            <Text style={styles.textStyle}>Address: {item.userAddress}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  idTextStyle:{
    color: '#BE5109',
    fontSize: 18,
    fontWeight: 'bold'
  },
  textStyle:{
    color: '#000000',
    fontSize: 18,
    fontWeight: 'bold'
  }
});

export default ShowAllUsers;
