import React from 'react';
import { Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import AddUser from './AddUser';
import Home from './HomeScreen';
import DeleteUser from './DeleteUser';
import SearchUser from './SearchUser';
import AllUsers from './ShowAllUsers';
import UpdateUser from './UpdateUser';

const Stack = createNativeStackNavigator();

function App() {
  return (
      <NavigationContainer>
        <Stack.Navigator initialRouteName="HomeScreen"
          screenOptions={{
          headerStyle: { backgroundColor: '#707F0A'},
          headerTitleStyle: {color: 'black'}
        }}>
          <Stack.Screen name="HomeScreen" component={Home}/>
          <Stack.Screen name="AddUser" component={AddUser}/>
          <Stack.Screen name="DeleteUser" component={DeleteUser}/>
          <Stack.Screen name="SearchUser" component={SearchUser}/>
          <Stack.Screen name="AllUsers" component={AllUsers}/>
          <Stack.Screen name="UpdateUser" component={UpdateUser}/>
        </Stack.Navigator>
      </NavigationContainer>
  );
}

export default App;
