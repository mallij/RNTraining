/*Screen to update the user*/
import React, {useState, useEffect} from 'react';
import {
  View,
  ScrollView,
  Alert,
} from 'react-native';
import CustomTextBox from '../components/CustomTextBox';
import PrimaryButton from '../components/PrimaryButton';
import Realm from 'realm';
let realm;

const UpdateUser = (props) =>{

  useEffect(() => {
    realm = new Realm({ path: 'UserInfo.realm' });
  }, []);
  const [userId, setUserId] = useState('');
  const [userName, setUserName] = useState('');
  const [userPhone, setUserPhone] = useState('');
  const [userAddress, setUserAddress] = useState('');

  searchUser = () => {
    var userDetails = realm
      .objects('User')
      .filtered('userId =' + userId);

    if (userDetails.length > 0) {
      const userData = userDetails[0];
      setUserName(userData.userName);
      setUserPhone(userData.userPhone);
      setUserAddress(userData.userAddress);
    } else {
      setUserName('');
      setUserPhone('');
      setUserAddress('');
      alert('No user found');
    }
  };
  updateUser = () => {
    if (userId) {
      if (userName) {
        if (userPhone) {
          if (userAddress) {
            realm.write(() => {
              var obj = realm
                .objects('User')
                .filtered('userId =' + userId);
              if (obj.length > 0) {
                obj[0].userName = userName;
                obj[0].userPhone = userPhone;
                obj[0].userAddress = userAddress;
                Alert.alert(
                  'Success',
                  'User updated successfully',
                  [
                    {
                      text: 'Ok',
                      onPress: () =>
                        props.navigation.navigate('HomeScreen'),
                    },
                  ],
                  { cancelable: false }
                );
              } else {
                alert('User Updation Failed');
              }
            });
          } else {
            alert('Please fill Address');
          }
        } else {
          alert('Please fill Contact Number');
        }
      } else {
        alert('Please fill Name');
      }
    } else {
      alert('Please fill User Id');
    }
  };

    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <ScrollView keyboardShouldPersistTaps="handled">
            <CustomTextBox
              placeholder="Enter User Id"
              onChangeText={user_id => setUserId(user_id)}
            />
            <PrimaryButton
              label="Search User"
              customClick={searchUser}
            />
            <CustomTextBox
              placeholder="Enter Name"
              value={userName}
              onChangeText={user_name => setUserName(user_name)}
            />
            <CustomTextBox
              placeholder="Enter Contact No"
              value={'' + userPhone}
              onChangeText={user_contact => setUserPhone(user_contact)}
              maxLength={10}
              keyboardType="numeric"
            />
            <CustomTextBox
              value={userAddress}
              placeholder="Enter Address"
              onChangeText={user_address => setUserAddress(user_address)}
              maxLength={225}
              numberOfLines={5}
              multiline={true}
              style={{ textAlignVertical: 'top' }}
            />
            <PrimaryButton
              label="Update User"
              customClick={updateUser}
            />
        </ScrollView>
      </View>
    );
}

export default UpdateUser;
