export const userTableSchema = {
  name: 'User',
  properties: {
    userId: { type: 'int', default: 0 },
    userName: 'string',
    userPhone: 'string',
    userAddress: 'string',
  },
  primaryKey:'userId';
};

export const userTableSchema = {
  name: 'User',
  properties: {
    userId: { type: 'int', default: 0 },
    userName: 'string',
    userPhone: 'string',
    userAddress: 'string',
  }
};
