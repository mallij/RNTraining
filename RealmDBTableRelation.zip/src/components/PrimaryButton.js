/*Custom Button*/

import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';

const PrimaryButton = (props) => {
  return(
    <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={props.customClick}>
        <Text
        style={styles.text}>
          {props.label}
        </Text>
    </TouchableOpacity>
    );
  }

const styles = StyleSheet.create({
  buttonStyle: {
    padding: 10,
    borderColor: 'black',
    borderWidth: 2,
    backgroundColor:'#f05555',
    marginVertical: 10,
    width: 150,
    borderRadius: 5,
    alignSelf: 'center'
  },
  text: {
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: 'bold'
  },
});
export default PrimaryButton;
