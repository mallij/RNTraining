
import React, {Component} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Image
} from 'react-native';
import styles from './styles/welcomeStyles';

class App extends Component{
  constructor()
  {
    super();
    this.state = {amount: 0, name: ''};
  }
  render(){
    const obj1 = {score: 100, grade: 8,  school: 'Bhavans'};
    const imagePath = require('../images/react_native.png');
    const {amount, name} = this.state; // Object Destructuring
    const {score, grade, school} = obj1;

    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 320, height: 280}} source={imagePath} />

      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />
      <Text style={styles.titleStyle}> TextInput Demo </Text>
      {console.log('<== Loaded ==>')}
      <TextInput
        style={styles.borderedTextStyle}
        placeholder={'Enter Name'}
        onChangeText={(text) => this.setState({name: text})}
      />

      <Text
      style={{textAlign: 'center', fontWeight: 'bold'}}>
      {score}
      </Text>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => verifyName()}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Check the Value
        </Text>
      </TouchableOpacity>

      <TextInput
        keyboardType={'number-pad'}
        maxLength={4}
        placeholder={'Enter amount'}
        style={amount < 200 ? styles.borderedTextStyle : styles.borderedTextErrorStyle}
        onChangeText={(text) => {
          // setAmount(text);
          this.setState({amount: text});
        }
        }
      />

      <Text
      style={{textAlign: 'center', fontWeight: 'bold'}}>
      {amount}
      </Text>
      {amount > 200 ? <Text style={styles.erroMessageStyle}> Invalid Amount </Text> : null}
      </View>
      </SafeAreaView>
      );
  }
}

export default App;
