import { StyleSheet } from 'react-native';

const welcomeStyles = StyleSheet.create(
  {
    titleStyle: {
      color: '#BE5109',
      fontSize: 20,
      fontWeight: 'bold'
    },
    messageStyle: {
      color: '#000000',
      fontSize: 18
    },
    erroMessageStyle: {
      color: '#F82C22',
      fontSize: 18
    },
    borderedTextStyle:{
      margin: 20,
      padding: 10,
      width: 200,
      borderColor: "#000000",
      borderWidth: 2,
    },
    borderedTextErrorStyle:{
      margin: 20,
      padding: 10,
      width: 200,
      borderColor: "#F82C22",
      borderWidth: 2
    },
    buttonStyle:{
      padding: 10,
      borderColor: 'black',
      borderWidth: 2,
      backgroundColor:'#2BB4CD',
      margin: 5,
      width: 150,
      borderRadius: 5
    }
  }
);

export default welcomeStyles;
