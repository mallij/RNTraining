
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  TextInput
} from 'react-native';
import styles from './styles/welcomeStyles';

const App = () => {
  // const [name, setName] = useState('No name');
  // const objValues = {name: 'No name'. pwd:''};
  var name = 'No name';
  const verifyName = () =>
  {
    if(name == '')
    {
      console.log('Please enter your name');
    }
    else {
      console.log('====> ', name);
    }
  }

  const [amount, setAmount] = useState(0);
  const [error, setError] = useState('Enter Amount');
  return(
    <SafeAreaView style={{ flex: 1 }}>
    <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
    <Text style={styles.titleStyle}> TextInput Demo </Text>
    {console.log('<== Loaded ==>')}
    <TextInput
      style={styles.borderedTextStyle}
      placeholder={'Enter Name'}
      onChangeText={(text) => name = text}
    />

    <TouchableOpacity
    style={styles.buttonStyle}
    activeOpacity = {1}
    onPress={() => verifyName()}>
      <Text
      style={{textAlign: 'center', fontWeight: 'bold'}}>
      Check the Value
      </Text>
    </TouchableOpacity>

    <TextInput
      keyboardType={'number-pad'}
      maxLength={2}
      style={amount < 200 ? styles.borderedTextStyle : styles.borderedTextErrorStyle}
      placeholder={error}
      onChangeText={(text) => {
        setAmount(text);
        // if(amount > 0 ? setError('Invalid Amount') : setError('Enter Amount'));
      }
      }
    />
    {amount > 200 ? <Text style={styles.erroMessageStyle}> Invalid Amount </Text> : null}
    </View>
    </SafeAreaView>
    );
}

export default App;
