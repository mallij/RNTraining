
import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Button,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback
  } from 'react-native';
  import styles from './styles/welcomeStyles';
  import PrimaryButton from './PrimaryButton';
  const App = () => {
    // Normal Component Data
    // var counter = 1;

    // Component State Data
    const [counter, setCounter] = useState(1);

    const incrementCounter = () => {
      // counter = counter + 1;
      // console.log('======> ', counter);
      setCounter(counter+1);
    }

    const decrementCounter = () => {
      // counter = counter - 1;
      // console.log('======> ', counter);
      setCounter(counter-1);
    }
    const obj = {obj1: incrementCounter, obj2:decrementCounter};
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      {console.log('<=== Loaded ===>')}
      <Text style={styles.titleStyle}> Component State  </Text>
      <Text style={styles.borderedTextStyle}> {counter} </Text>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => incrementCounter()}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Increment Number
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => decrementCounter()}>
      <Text
      style={{textAlign: 'center', fontWeight: 'bold'}}>
      Decrement Number
      </Text>
      </TouchableOpacity>
      </View>
      </SafeAreaView>
      );
    }

    export default App;
