
import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  Modal
} from 'react-native';
import styles from './styles/welcomeStyles';

const App = () => {
  const [isModalVisible, setModalVisible] = useState(true);
  const showAlert = () =>{

    Alert.alert(
      'Simple Alert', // A title for the alert pop-up
      'I am just a simple Alert', // Message in the pop-up
      [ // Buttons that are to be part of this pop-up
        {
          text: "Ok",
          onPress: () => console.log("Cancel Pressed")
        },
        {
          text: 'Good',
          onPress: () => console.log("Sounds Good"),
          style: 'cancel'
        }
      ]
    );
  }

    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Image style={{width: 100, height: 100}}
      source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} />
      <Text style={styles.titleStyle}> Alert & Model Demo </Text>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => showAlert()}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Show Alert
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.buttonStyle}
      activeOpacity = {1}
      onPress={() => setModalVisible(!isModalVisible)}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
        Show Modal
        </Text>
      </TouchableOpacity>

      <Modal
        animationType="fade"
        transparent={true}
        visible={isModalVisible}
        >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>Hello Modal</Text>

            <TouchableOpacity
            style={styles.buttonStyle}
            activeOpacity = {1}
            onPress={() => setModalVisible(!isModalVisible)}>
              <Text
              style={{textAlign: 'center', fontWeight: 'bold'}}>
              Hide Modal
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      </View>
      </SafeAreaView>
      );
}

export default App;
