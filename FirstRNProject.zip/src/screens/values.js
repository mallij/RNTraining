
export default multiplyNumbers = (a, b) => {
  var product = a*b;
  console.log('Product is ===> ', product);
  return product;
};

export const addNumbers = (a, b) =>{
  var sum = a+b;
  console.log('Sum is ===> ', sum);
  return sum;
};
