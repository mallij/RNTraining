import { StyleSheet } from 'react-native';

const welcomeStyles = StyleSheet.create(
  {
    titleStyle: {
      color: '#BE5109',
      fontSize: 20,
      fontWeight: 'bold'
    },
    messageStyle: {
      color: '#000000',
      fontSize: 18
    },
    borderedTextStyle:{
      color: '#000000',
      fontSize: 18,
      margin: 20,
      borderColor: "#000000",
      borderWidth: 2,
    }
  }
);

export default welcomeStyles;
