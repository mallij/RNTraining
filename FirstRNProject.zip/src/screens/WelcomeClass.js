import React, { Component } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Button,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback
  } from 'react-native';
import welcomeStyles from './styles/welcomeStyles';

class WelcomeClass extends Componet{
  constructor()
  {
    super();
  }

  render(){
    var counter = 1;
    return(
      <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center'}}>
      <Text style={welcomeStyles.titleStyle}> Basic UI Elements  </Text>
      <Text style={welcomeStyles.borderedTextStyle}> {counter} </Text>

      <Button
      title='Click to Increase'
      color='blue'
      onPress={() => {incrementCounter()}} />

      <TouchableOpacity
        style={{ padding: 10, borderColor: 'black', borderWidth: 2,
        backgroundColor:'#087570'}}
        activeOpacity = {1}
        onPress={() => {incrementCounter()}}>
          <Text> Click - Opacity </Text>
      </TouchableOpacity>

      <TouchableHighlight
        style={{ padding: 10, borderColor: 'black', borderWidth: 2,
        backgroundColor:'#B0E031', marginVertical: 20}}
        activeOpacity = {0.1}
        underlayColor={'#0EBFF8'}
        onPress={() => {incrementCounter()}}>
          <Text> Click - Highlight </Text>
      </TouchableHighlight>

      <TouchableWithoutFeedback
        style={{ padding: 10, borderColor: 'black', borderWidth: 2,
        backgroundColor:'#B0E031', marginVertical: 20}}
        onPress={() => {incrementCounter()}}>
          <Text> Click - Without Feedback </Text>
      </TouchableWithoutFeedback>

      </View>
      </SafeAreaView>
    );
  };
}

export default WelcomeClass;
