/**
* Sample React Native App
* https://github.com/facebook/react-native
*
* @format
* @flow strict-local
*/

import React from 'react';
import { Text, TouchableOpacity } from 'react-native';

import welcomeStyles from '../screens/styles/welcomeStyles';

const PrimaryButton = (props) => {
  return(
    <TouchableOpacity
      style={{ padding: 10, borderColor: 'black', borderWidth: 2,
      backgroundColor:props.bgColor, margin: 5, width: 150, borderRadius: 5}}
      activeOpacity = {1}
      onPress={props.onClick}>
        <Text
        style={{textAlign: 'center', fontWeight: 'bold'}}>
          {props.label}
        </Text>
    </TouchableOpacity>
    );
  }

export default PrimaryButton;
