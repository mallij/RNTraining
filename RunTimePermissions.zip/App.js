import React, {useState} from "react";
import {
  Button,
  PermissionsAndroid,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Platform
} from "react-native";

import GetLocation from 'react-native-get-location';

const App = () => {
  const [permission, setPermission] = useState('Permission is not given yet');
  const [location, setLocation] = useState('No Location Found');
  const requestLocationPermission = async () => {
    if(Platform.OS === 'ios')
    {
      readLocation();
    }
    else{
      try {
        const checkLocationStatus = await PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
          console.log('=====> ',checkLocationStatus);
          if(checkLocationStatus){
            setPermission('Location permission is already given');
            readLocation();
          }
          else{
            const granted = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, // Permission Name
              {
                title: "This App Needs Location Permission",
                message:
                  "This app is going to read your location data to locate you on Map",
                buttonNeutral: "Ask Me Later",
                buttonNegative: "Cancel",
                buttonPositive: "Allow"
              }
            );

            // The Second parameter in the above request method is to show to the user
            // if he denied the permission already, This info will be shown to explain
            // why the permission is to be granted

            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
              setPermission('Location permission is given');
              readLocation();
            } else {
              setPermission('Location permission is denied');
            }
          }
      } catch (err) {
        console.warn(err);
      }
    }
  };

  const readLocation = async() =>{
    try{
      const location = await
      GetLocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 15000,
      });
      console.log('=====> ',location);
      setLocation(location.latitude+" <=> "+location.longitude);
    }
    catch(error){
        const { code, message } = error;
        console.log(code, message);
    }
  }

  return (
  <View style={styles.container}>
    <Text style={styles.item}>Runtime permissions</Text>
    <Button title="Request Location Permission" onPress={requestLocationPermission} />
    <Text style={styles.itemResult}>{permission}</Text>
    <Text style={styles.itemResult}>{location}</Text>
  </View>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    paddingTop: 20,
    backgroundColor: "#ecf0f1",
    padding: 8
  },
  item: {
    margin: 24,
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center"
  },
  itemResult: {
    margin: 24,
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    color:'#595F1B'
  }
});

export default App;
